#include <iostream>

using namespace std;
const int NUM_MONKEYS = 3;
const int NUM_DAYS = 5;
int monkeyFood[NUM_MONKEYS][NUM_DAYS];

double averagePerDay(int mfood[NUM_MONKEYS][NUM_DAYS], int day){
double average=0;
for(int i=0;i<NUM_MONKEYS;i++)
{

    average+=mfood[i][day];
}

    return average/3.0;

}

double leastPerWeekByAnyOneMonkey (int mfood[NUM_MONKEYS][NUM_DAYS]){
double leastfood;
leastfood=mfood[0][0]+mfood[0][1]+mfood[0][2]+mfood[0][3]+mfood[0][4];
double monkeyWeekl = leastfood;
for(int i=1;i<NUM_MONKEYS;i++){
 monkeyWeekl = mfood[i][0] + mfood[i][1] + mfood[i][2]+mfood[i][3]+mfood[i][4];
for(int j=0;j<NUM_DAYS;j++){
if(monkeyWeekl<leastfood)
    leastfood = monkeyWeekl;
   }
  }

return leastfood;
}


double greatestPerWeekByAnyOneMonkey(int mfood[NUM_MONKEYS][NUM_DAYS]){
   double highestfood;
  highestfood=mfood[0][0]+mfood[0][1]+mfood[0][2]+mfood[0][3]+mfood[0][4];
  double monkeyweekh=highestfood;
for(int i=0;i<NUM_MONKEYS;i++){
        monkeyweekh=mfood[i][0]+mfood[i][1]+mfood[i][2]+mfood[i][3]+mfood[i][4];
 for(int j=0;j<NUM_DAYS;j++){
  if(monkeyweekh>highestfood)
   highestfood=monkeyweekh;
     }
  }

return highestfood;
}

int main()
{
    for(int i = 0; i < NUM_MONKEYS; i++){
        cout << "Enter the information for monkey " << (i+1) << endl;
        for(int j = 0; j < NUM_DAYS; j++){
            cout << "Enter the information for day " << (j + 1) << endl;
            cin >> monkeyFood[i][j];
        }
    }
    cout << averagePerDay(monkeyFood, 0) << endl;
    cout << leastPerWeekByAnyOneMonkey(monkeyFood) << endl;
    cout << greatestPerWeekByAnyOneMonkey(monkeyFood) << endl;


    return 0;
}
